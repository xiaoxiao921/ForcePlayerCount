# Force Player Count

Overrides the game's player count with a fixed value.

### Risk of Options

Risk of Options is required, an entry in the game Settings will appear to configure the player count in-game.

## Changelog

### v1.0.0
- Initial release